-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 08 2023 г., 06:41
-- Версия сервера: 5.7.39-log
-- Версия PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `test_curse`
--

-- --------------------------------------------------------

--
-- Структура таблицы `lesson`
--

CREATE TABLE `lesson` (
  `id` int(11) NOT NULL,
  `number` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `video` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `lesson`
--

INSERT INTO `lesson` (`id`, `number`, `title`, `description`, `video`) VALUES
(1, 1, 'Изучение Next JS с нуля / Урок #1 – Введение в NextJS для начинающих. Что это?', 'Представляем вам курс по изучению Next JS для начинающих. В курсе вы с нуля научитесь работать с фреймворком NextJS. Вы узнаете где он применяется', 'https://www.youtube.com/embed/cAvIwaucvQM'),
(2, 2, 'Создание проекта и его настройка\n', 'В ходе урока мы создадим новый Next JS проект и выполним его настройку. Дополнительно вы ознакомитесь со структурой проекта, а также научитесь отслеживать разные URL адреса.\n', 'https://www.youtube.com/embed/7jtb7dKo1tM'),
(3, 3, 'Отслеживание URL и работа со стилями', 'За урок вы изучите разные варианты обработки URL адресов. Вы научитесь создавать динамические страницы и получать данные из URL. Также вы познакомитесь с добавлением стилей к сайту.', 'https://www.youtube.com/embed/QAG7UsaPwbI'),
(4, 4, 'Получение и обработка данных', 'В этом уроке мы научимся обрабатывать данные', 'https://www.youtube.com/embed/24l5_tC9_O4'),
(5, 5, 'Отдельные страницы с информацией', 'В уроке мы создадим отдельные динамические страницы для вывода информации про статью. Такие страницы будут формироваться в зависимости от параметра в URL адресе.', 'https://www.youtube.com/embed/j0z3ujquxXM'),
(6, 6, 'Работа с API Routes', 'За урок мы научимся описывать серверную часть приложения на базе фреймворка Next JS. Мы ознакомимся с использованием API Routes и обработке разных типов запросов: GET, POST, PUT, DELETE.\n', 'https://www.youtube.com/embed/jka0IM3MKYE'),
(7, 7, 'Добавление мета данных\n', 'К сайтам, что созданы при помощи Next JS можно легко добавить настройки мета данных к каждой отдельной странице. За урок вы научитесь прописывать мета данные, а также создадите динамически генерируемые статические данные.\n', 'https://www.youtube.com/embed/ElcZVhv54ac'),
(8, 8, 'Экспорт проекта. Заключительная часть', 'За урок мы с вами ознакомимся с построением и экспортом проекта. Дополнительно мы подведем итоги изученного, а также определимся с тем куда двигаться далее.\n', 'https://www.youtube.com/embed/PRYa9JPRkTY');

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_information`
--

CREATE TABLE `lesson_information` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `lesson_information`
--

INSERT INTO `lesson_information` (`id`, `lesson_id`, `user_id`, `status`) VALUES
(14, 1, 1, 1),
(15, 2, 1, 1),
(16, 3, 1, 1),
(17, 4, 1, 1),
(18, 5, 1, 1),
(19, 6, 1, 1),
(20, 7, 1, 1),
(21, 1, 2, 1),
(22, 2, 2, 1),
(23, 2, 2, 2),
(24, 3, 2, 1),
(25, 4, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1701933337),
('m231206_144326_create_user_table', 1701933344),
('m231206_144328_create_lesson_table', 1701933344),
('m231206_144329_create_lesson_information_table', 1701933344);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', '6nxbf9NOGwVEHyeRDBesdA90Wgdjmo2l', '$2y$13$kQexiTqYF/ZwMaRnlf035OXH0flHssDvhE0QX2cyUktsVOuHZE3JO', NULL, 'admin@admin.admin', 10, 1701933412, 1701933412),
(2, 'user', '907XYfEWKiEgLIQO44tzFzNpcmfgFrko', '$2y$13$Z.g51/cpNh3kVN38vXaHeOIIqxauHOnNMHhn30xKrjocBGghnn7NK', NULL, 'user@user.user', 10, 1701944149, 1701944149),
(3, 'user_1', 'AAZtt2hjeNrWyzdFGFKataOG8OUbzGwu', '$2y$13$45cHQ8n6ZpxJQvYzjLeOKO0UggKnpp62N65hSosh3T2Z0UnwfiXPe', NULL, 'user_1@user_1.user_1', 10, 1701944149, 1701944149);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `lesson`
--
ALTER TABLE `lesson`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `lesson_information`
--
ALTER TABLE `lesson_information`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `lesson`
--
ALTER TABLE `lesson`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `lesson_information`
--
ALTER TABLE `lesson_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
